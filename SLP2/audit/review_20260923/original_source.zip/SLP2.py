"""SLP2 -- live MT5 bot for the SP2L spike+gap+pullback pattern (ported
from AlirezaSadabadi/PythonTraderBot's SP2L_Advanced_Bot_Optimized.py),
retimed to M15 and walk-forward optimized on XAUUSD.

Strategy: 4-candle spike+gap setup -> pending pullback entry -> EMA(20)
trend filter -> trend-structure filter (max 2 opposite moves while
waiting) -> SL at the pre-spike extreme, TP at 3R. Config below was
train-derived and independently re-derived (same result) across 50/50,
60/40 and 70/30 walk-forward splits of 4.3 years of M15 data, then
sanity-checked with true bid/ask tick execution over 6 months
(scripts/sp2l_m15_optimize.py, scripts/sp2l_m15_tick_backtest.py).

Pattern detection is imported directly from scripts/sp2l_m15_backtest.py
so this live bot can never silently drift from the backtested logic.

SAFETY
------
Defaults to DRY RUN: evaluates signals and logs what it *would* do, but
never calls mt5.order_send. Pass --live to submit real orders on whatever
account MT5 is currently logged into. TEST ON A DEMO ACCOUNT FIRST. Check
SYMBOL, RISK_PCT and the connected account before ever using --live on a
funded account.
"""

import argparse
import json
import logging
import math
import os
import sys
import time
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR
from logging.handlers import RotatingFileHandler
from pathlib import Path

import MetaTrader5 as mt5
import pandas as pd

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))

from bot.mt5_data import get_bars, get_tick, account, positions, get_symbol_info, utc_now  # noqa: E402
from bot.risk import lots_for_risk, validate_risk  # noqa: E402
from sp2l_m15_backtest import add_indicators, detect_buy_setup, detect_sell_setup  # noqa: E402

# ---------------- locked strategy config (train-derived, split-validated) ----------------
SYMBOL = "XAUUSD"
SPIKE_CANDLE_SIZE = 1.5
PGAP_DOLLARS = 2.0
MAX_SL_DOLLARS = 10.0
TP_R = 3.0
USE_EMA_FILTER = True
EMA_PERIOD = 20
USE_TREND_FILTER = True
MAX_OPPOSITE_MOVES = 2

RISK_PCT = 0.002            # 0.2% of equity per trade
COMMISSION_PER_LOT = 7.0
MAGIC = 20260223            # distinct from bot/config.py's BB+RSI bot (MAGIC=990001)
DEVIATION_POINTS = 20
MAX_SIGNAL_AGE_MIN = 20      # ignore a trigger bar older than this (bot was down / caught up late)
BARS_NEEDED = 250            # EMA(20) warmup + pattern lookback, generous margin

POLL_SECONDS = 15
RUNTIME_DIR = ROOT / "runtime"
STATE_PATH = RUNTIME_DIR / "slp2_state.json"
LOG_PATH = RUNTIME_DIR / "slp2.log"
LOCK_PATH = RUNTIME_DIR / "slp2.lock"


# ============================================================
# state (tiny, restart-safe idempotency guard only -- the
# pattern itself is re-derived fresh from price history every
# poll, so nothing strategy-relevant needs to survive a restart)
# ============================================================

def load_state():
    if STATE_PATH.exists():
        try:
            return json.loads(STATE_PATH.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
    return {"last_entry_bar_time": None}


def save_state(state):
    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    tmp = STATE_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(state), encoding="utf-8")
    os.replace(tmp, STATE_PATH)


def acquire_lock():
    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    f = open(LOCK_PATH, "a+b")
    try:
        if os.name == "nt":
            import msvcrt
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        raise RuntimeError("Another SLP2 instance already holds the lock (runtime/slp2.lock)")
    return f  # keep the handle alive for the process lifetime


# ============================================================
# pattern replay -- identical control flow to
# scripts/sp2l_m15_backtest.simulate(): a still-unresolved
# pending setup does not block fresh setup detection on the
# same bar (matches SP2L_Advanced_Bot_Optimized.py's Strategy()
# fallthrough), but this whole scan is skipped entirely while a
# position is open, mirroring status=True.
# ============================================================

def latest_pending_and_trigger(df):
    """Replays the full fetched window and returns (pending_or_None,
    trigger) where trigger, if not None, means the LAST bar in df is a
    fresh, validated entry with keys direction/entry/stop/target."""
    df = add_indicators(df, ema_period=EMA_PERIOD)
    o, h, l, c = df["open"].to_numpy(), df["high"].to_numpy(), df["low"].to_numpy(), df["close"].to_numpy()
    ema = df["EMA"].to_numpy()
    bar_time = df["bar_time"].to_numpy()
    n = len(df)
    last_i = n - 1

    pending = None
    trigger = None

    for i in range(4, n):
        entered = False
        if pending is not None:
            direction = pending["direction"]
            start_pos = pending["setup_pos"]
            if direction == "BUY":
                if l[i] < l[i - 1]:
                    entry, sl = l[i], pending["sl"]
                    risk = entry - sl
                    if risk <= 0 or risk > MAX_SL_DOLLARS:
                        pending = None
                    else:
                        ok = True
                        if USE_TREND_FILTER:
                            opp = 0
                            for pos in range(start_pos + 1, i + 1):
                                if h[pos] > h[pos - 1]:
                                    opp = 0
                                else:
                                    opp += 1
                                    if opp > MAX_OPPOSITE_MOVES:
                                        ok = False
                                        break
                        if ok and USE_EMA_FILTER:
                            if not (ema[i] == ema[i]) or c[i] <= ema[i]:  # NaN-safe isfinite check
                                ok = False
                        if ok:
                            if i == last_i:
                                trigger = dict(direction=1, entry=entry, stop=sl,
                                               target=entry + TP_R * risk, bar_time=pd.Timestamp(bar_time[i]))
                            pending = None
                            entered = True
            else:
                if h[i] > h[i - 1]:
                    entry, sl = h[i], pending["sl"]
                    risk = sl - entry
                    if risk <= 0 or risk > MAX_SL_DOLLARS:
                        pending = None
                    else:
                        ok = True
                        if USE_TREND_FILTER:
                            opp = 0
                            for pos in range(start_pos + 1, i + 1):
                                if l[pos] < l[pos - 1]:
                                    opp = 0
                                else:
                                    opp += 1
                                    if opp > MAX_OPPOSITE_MOVES:
                                        ok = False
                                        break
                        if ok and USE_EMA_FILTER:
                            if not (ema[i] == ema[i]) or c[i] >= ema[i]:
                                ok = False
                        if ok:
                            if i == last_i:
                                trigger = dict(direction=-1, entry=entry, stop=sl,
                                               target=entry - TP_R * risk, bar_time=pd.Timestamp(bar_time[i]))
                            pending = None
                            entered = True

        if entered:
            continue

        if detect_buy_setup(o, h, l, c, i, PGAP_DOLLARS, spike_size=SPIKE_CANDLE_SIZE):
            pending = dict(direction="BUY", setup_pos=i, sl=l[i - 3])
        elif detect_sell_setup(o, h, l, c, i, PGAP_DOLLARS, spike_size=SPIKE_CANDLE_SIZE):
            pending = dict(direction="SELL", setup_pos=i, sl=h[i - 3])

    return pending, trigger


# ============================================================
# execution
# ============================================================

def filling_mode(info):
    if info.filling_mode & 1:
        return mt5.ORDER_FILLING_FOK
    if info.filling_mode & 2:
        return mt5.ORDER_FILLING_IOC
    if info.trade_exemode != mt5.SYMBOL_TRADE_EXECUTION_MARKET:
        return mt5.ORDER_FILLING_RETURN
    raise RuntimeError("Symbol offers no supported market filling policy")


def quantize_price(price, info, up):
    step = Decimal(str(info.trade_tick_size))
    if step <= 0 or not math.isfinite(price) or price <= 0:
        raise ValueError("Invalid price/tick size")
    value = (Decimal(str(price)) / step).to_integral_value(
        rounding=ROUND_CEILING if up else ROUND_FLOOR) * step
    return float(value)


def has_open_position(logger):
    for pos in positions(SYMBOL):
        if pos.magic == MAGIC:
            return True
    return False


def place_order(trigger, live, logger):
    d = trigger["direction"]
    info, tick = get_symbol_info(SYMBOL), get_tick(SYMBOL)
    entry_ref = tick.ask if d == 1 else tick.bid
    stop_dist_ref = abs(entry_ref - trigger["stop"])
    if stop_dist_ref <= 0 or stop_dist_ref > MAX_SL_DOLLARS * 2:
        logger.warning("Skipping trigger %s: live stop distance %.2f looks stale/invalid vs signal", trigger, stop_dist_ref)
        return None

    acc = account()
    lots = lots_for_risk(SYMBOL, stop_dist_ref, RISK_PCT, direction=d, entry=entry_ref,
                         stop=trigger["stop"], equity=acc.equity)
    if lots <= 0:
        logger.info("Computed lot size is 0 (risk budget too small for min lot); skipping")
        return None

    sl = quantize_price(trigger["stop"], info, up=(d == -1))
    tp = quantize_price(trigger["target"], info, up=(d == 1))
    reference = tick.bid if d == 1 else tick.ask
    minimum = max(info.trade_stops_level * info.point, info.trade_tick_size)
    if d * (reference - sl) < minimum or d * (tp - reference) < minimum:
        logger.warning("SL/TP violates broker minimum stop distance; skipping this trigger")
        return None

    request = dict(action=mt5.TRADE_ACTION_DEAL, symbol=SYMBOL, volume=lots,
                   type=mt5.ORDER_TYPE_BUY if d == 1 else mt5.ORDER_TYPE_SELL,
                   sl=sl, tp=tp, deviation=DEVIATION_POINTS, magic=MAGIC,
                   comment="slp2:" + trigger["bar_time"].strftime("%Y%m%d%H%M"),
                   type_time=mt5.ORDER_TIME_GTC, type_filling=filling_mode(info))
    if info.trade_exemode != mt5.SYMBOL_TRADE_EXECUTION_MARKET:
        request["price"] = entry_ref

    logger.info("SIGNAL %s %s lots=%.2f entry~%.2f sl=%.2f tp=%.2f (setup bar %s)",
               "BUY" if d == 1 else "SELL", SYMBOL, lots, entry_ref, sl, tp, trigger["bar_time"])

    if not live:
        logger.info("DRY RUN -- no order sent (pass --live to trade for real)")
        return "dry_run"

    check = mt5.order_check(request)
    if check is None or check.retcode != 0:
        logger.error("Order preflight rejected: %s", check)
        return None
    result = mt5.order_send(request)
    logger.info("order_send result: %s", result)
    return result


# ============================================================
# main loop
# ============================================================

def setup_logger():
    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("slp2")
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        for handler in (RotatingFileHandler(LOG_PATH, maxBytes=5_000_000, backupCount=3, encoding="utf-8"),
                       logging.StreamHandler()):
            handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
            logger.addHandler(handler)
    return logger


def run(live):
    logger = setup_logger()
    _lock_handle = acquire_lock()
    validate_risk(RISK_PCT)

    if not mt5.initialize():
        raise RuntimeError(f"MT5 initialize failed: {mt5.last_error()}")
    try:
        acc = account()
        logger.info("Starting SLP2 mode=%s account=%s:%s symbol=%s risk_pct=%.3f%% magic=%s",
                   "LIVE" if live else "DRY-RUN", acc.server, acc.login, SYMBOL, RISK_PCT * 100, MAGIC)
        if live:
            logger.warning("LIVE MODE -- real orders will be submitted to the connected account")
        if not mt5.symbol_select(SYMBOL, True):
            raise RuntimeError(f"Symbol unavailable: {SYMBOL}")

        state = load_state()
        while True:
            try:
                now = utc_now()
                df = get_bars(SYMBOL, "M15", BARS_NEEDED, asof=now)
                last_bar_time = df["bar_time"].iloc[-1]
                age_min = (now - last_bar_time).total_seconds() / 60

                if has_open_position(logger):
                    time.sleep(POLL_SECONDS)
                    continue

                pending, trigger = latest_pending_and_trigger(df)

                if trigger is not None:
                    bar_key = str(trigger["bar_time"])
                    already_acted = state.get("last_entry_bar_time") == bar_key
                    if already_acted:
                        pass
                    elif age_min > MAX_SIGNAL_AGE_MIN:
                        logger.info("Trigger on %s is %.1f min stale (>%.0f); skipping",
                                   trigger["bar_time"], age_min, MAX_SIGNAL_AGE_MIN)
                        state["last_entry_bar_time"] = bar_key
                        save_state(state)
                    else:
                        place_order(trigger, live, logger)
                        state["last_entry_bar_time"] = bar_key
                        save_state(state)
                elif pending is not None:
                    logger.debug("Pending %s setup from bar %s, waiting for pullback",
                                pending["direction"], pending["setup_pos"])
            except Exception:
                logger.exception("Poll iteration failed; will retry")
            time.sleep(POLL_SECONDS)
    except KeyboardInterrupt:
        logger.info("Stopped by user")
    finally:
        mt5.shutdown()


def main():
    parser = argparse.ArgumentParser(description="SLP2 -- SP2L pattern bot on M15 (dry-run by default)")
    parser.add_argument("--live", action="store_true", help="Submit real orders on the connected MT5 account")
    args = parser.parse_args()
    run(args.live)


if __name__ == "__main__":
    main()
