"""User-specified price-action strategy on M15:

1. Detect swing highs/lows (fractal: 2 bars each side).
2. Track market structure; a close beyond the last opposite swing point is a
   trend change (Break of Structure).
3. While the new trend is active, look for 3 consecutive same-direction
   candles where each candle's open/low/close (bullish) or open/high/close
   (bearish) is more extreme than the previous one, AND the middle candle
   leaves a Fair Value Gap between candle 1 and candle 3.
4. Enter at the close of the 3rd candle. Stop = the extreme (low/high) across
   the 3 candles. Target = fixed R:R from entry.
"""

import sys
import pandas as pd
import numpy as np

sys.path.insert(0, r"E:\D drive\flat_trend_scalp_bot")
from bot.indicators import atr as _atr

M15_PATH = r"E:\D drive\flat_trend_scalp_bot\data\XAUUSD_M15_5y.parquet"  # ~4.3 years (2022-06 -> now), full broker history
H1_PATH = r"E:\D drive\flat_trend_scalp_bot\data\XAUUSD_H1_full.parquet"
# All values below are the walk-forward-derived config (re-optimized from
# scratch on the TRAIN-only split, see scripts/out_of_sample_validation.py),
# not values tuned on the full dataset. FRACTAL_LEGS=3 barely beat 2; larger
# values (10-30) were clearly worse on train.
FRACTAL_LEGS = 3  # bars required on each side to confirm a swing point
# Validated train -> test: 3 (initial request) was clearly worse than no filter
# (avg_r -0.059 on train); 10 was the train-optimal value and also improved
# the out-of-sample test result (avg_r 0.026 -> 0.084, recovery 0.11 -> 0.45).
MAX_BARS_FROM_TURN = 10  # candle 1 of the pattern must start within this many bars of the swing point
H1_FRACTAL_LEGS = 2  # same fractal method, applied to H1 bars instead of M15
USE_H1_FILTER = False  # removed per request; counter-H1 mode gave a small train-validated
                        # improvement (test avg_r 0.026 -> 0.042) but is disabled for now
H1_MODE = "counter"  # kept for reference if the H1 filter is re-enabled later
PIP = 0.10  # XAUUSD: 1 pip = $0.10 (10 points at point_size=0.01); adjust if you mean 0.01
MIN_GAP = 1.50  # legacy fixed-dollar value; superseded by MIN_GAP_ATR_MULT below
MIN_GAP_ATR_MULT = 0.4  # gap requirement relative to ATR(14) instead of a fixed dollar amount
RR = 4.0  # train-derived; out-of-sample test showed avg_r=+0.026 with this full config
# Removed: out-of-sample validation showed the "bad hours" set is unstable --
# it came out completely different when re-derived on the train-only split
# ([2,5,9,13,14,18,19] and then [2,3,4,10,13,18,19] for two different ATR
# settings), meaning it was tracking dataset-specific noise, not a real effect.
BAD_HOURS = set()
EMA_TREND_PERIOD = 200
USE_EMA_FILTER = False  # train-derived: EMA200 "against" trades actually did BETTER on train, so filter is off


def load_m15():
    df = pd.read_parquet(M15_PATH).sort_values("bar_time").reset_index(drop=True)
    df["ema_trend"] = df["close"].ewm(span=EMA_TREND_PERIOD, adjust=False).mean()
    df["atr"] = _atr(df, 14)
    return df


def load_h1():
    return pd.read_parquet(H1_PATH).sort_values("bar_time").reset_index(drop=True)


def attach_h1_trend(m15_df, h1_df, legs=H1_FRACTAL_LEGS):
    """Computes the same fractal-swing trend on H1 bars, then merges it onto
    the M15 frame causally: an M15 decision at time T only ever sees an H1
    trend value from an H1 bar that had FULLY CLOSED (bar_time + 1h) at or
    before T."""
    h1 = h1_df.copy()
    sh, sl = find_swings(h1, legs=legs)
    h1["h1_trend"] = trend_state(h1, sh, sl, legs=legs)
    h1["available_at"] = h1["bar_time"] + pd.Timedelta(hours=1)

    m15 = m15_df.sort_values("bar_time").reset_index(drop=True)
    m15["decision_time"] = m15["bar_time"] + pd.Timedelta(minutes=15)  # when the M15 bar actually closes
    merged = pd.merge_asof(m15, h1[["available_at", "h1_trend"]],
                           left_on="decision_time", right_on="available_at", direction="backward")
    m15_df = m15_df.copy()
    m15_df["h1_trend"] = merged["h1_trend"].values
    return m15_df


def find_swings(df, legs=FRACTAL_LEGS):
    high, low = df["high"].values, df["low"].values
    n = len(df)
    swing_high = np.zeros(n, dtype=bool)
    swing_low = np.zeros(n, dtype=bool)
    for i in range(legs, n - legs):
        window_h = high[i - legs:i + legs + 1]
        window_l = low[i - legs:i + legs + 1]
        if high[i] == window_h.max() and np.argmax(window_h) == legs:
            swing_high[i] = True
        if low[i] == window_l.min() and np.argmin(window_l) == legs:
            swing_low[i] = True
    return swing_high, swing_low


def trend_state(df, swing_high, swing_low, legs=FRACTAL_LEGS):
    """Returns an array: +1 = look for bullish setups (most recent confirmed
    fractal was a swing LOW -- the 'corner' itself marks the turn), -1 = look
    for bearish setups (most recent confirmed fractal was a swing HIGH),
    0 = no swing point confirmed yet. No structure-break/level-close
    confirmation is used -- the fractal point itself is the trend change."""
    n = len(df)
    trend = np.zeros(n, dtype=int)
    cur_trend = 0
    for i in range(n):
        confirm_idx = i - legs
        if confirm_idx >= 0:
            if swing_low[confirm_idx]:
                cur_trend = 1
            elif swing_high[confirm_idx]:
                cur_trend = -1
        trend[i] = cur_trend
    return trend


def trend_origin(df, swing_high, swing_low, legs=FRACTAL_LEGS):
    """Companion to trend_state: for each bar, the bar INDEX of the fractal
    swing point (the actual turning point candle) that set the trend value
    active at that bar. -1 if no swing point confirmed yet."""
    n = len(df)
    origin = np.full(n, -1, dtype=int)
    cur_origin = -1
    for i in range(n):
        confirm_idx = i - legs
        if confirm_idx >= 0 and (swing_low[confirm_idx] or swing_high[confirm_idx]):
            cur_origin = confirm_idx
        origin[i] = cur_origin
    return origin


def three_candle_pattern(df, i, direction, min_gap_mult=MIN_GAP_ATR_MULT, min_fvg=0.0, require_fvg=True):
    """Checks bars [i-2, i-1, i] for the strict progressive pattern + FVG
    created by the middle bar (i-1). The low/high progression gap is required
    to be at least min_gap_mult * ATR(14) at candle 1 -- adaptive to whatever
    volatility regime is active, instead of a fixed dollar amount.
    require_fvg=False drops the imbalance requirement entirely. Tested and
    reverted: looked good with the OLD fixed params (legs=3/gap=0.4/RR=4), but
    a full train-only re-derivation of every parameter with require_fvg=False
    produced a clearly negative out-of-sample result (avg_r -0.154). Kept
    True."""
    c1, c2, c3 = df.iloc[i - 2], df.iloc[i - 1], df.iloc[i]
    if pd.isna(c1.atr) or c1.atr <= 0:
        return False
    min_gap = min_gap_mult * c1.atr
    if direction == 1:
        bullish = c1.close > c1.open and c2.close > c2.open and c3.close > c3.open
        progressive = (c2.low >= c1.low + min_gap and c2.open > c1.open and c2.close > c1.close and
                       c3.low >= c2.low + min_gap and c3.open > c2.open and c3.close > c2.close)
        if not require_fvg:
            return bullish and progressive
        fvg_size = c3.low - c1.high
        return bullish and progressive and fvg_size >= min_fvg
    else:
        bearish = c1.close < c1.open and c2.close < c2.open and c3.close < c3.open
        progressive = (c2.high <= c1.high - min_gap and c2.open < c1.open and c2.close < c1.close and
                       c3.high <= c2.high - min_gap and c3.open < c2.open and c3.close < c2.close)
        if not require_fvg:
            return bearish and progressive
        fvg_size = c1.low - c3.high
        return bearish and progressive and fvg_size >= min_fvg


def generate_signals(df, min_gap_mult=MIN_GAP_ATR_MULT, min_fvg=0.0, trend=None, bad_hours=BAD_HOURS,
                     use_ema_filter=USE_EMA_FILTER, use_h1_filter=USE_H1_FILTER, h1_mode="aligned",
                     require_fvg=True, max_bars_from_turn=MAX_BARS_FROM_TURN, trend_origin_arr=None):
    """h1_mode: 'aligned' = only trade WITH the H1 fractal trend, 'counter' =
    only trade AGAINST it (validated better on train: a fresh M15 reversal
    against an aging H1 swing tends to have more room to run).
    max_bars_from_turn: candle 1 of the 3-candle pattern (bar i-2) must start
    within this many bars of the fractal swing point (the turning-point
    candle itself) -- requires a FRESH reversal, not a pattern deep inside an
    already-running move. Set to None to disable."""
    if trend is None:
        swing_high, swing_low = find_swings(df)
        trend = trend_state(df, swing_high, swing_low)
        if max_bars_from_turn is not None and trend_origin_arr is None:
            trend_origin_arr = trend_origin(df, swing_high, swing_low)
    if max_bars_from_turn is not None and trend_origin_arr is None:
        raise ValueError("max_bars_from_turn requires trend_origin_arr when trend is precomputed externally")
    if use_h1_filter and "h1_trend" not in df.columns:
        raise ValueError("use_h1_filter=True requires df from attach_h1_trend() first")
    signals = []
    for i in range(2, len(df)):
        d = trend[i]
        if d == 0:
            continue
        if max_bars_from_turn is not None:
            origin = trend_origin_arr[i]
            if origin < 0 or (i - 2) - origin > max_bars_from_turn:
                continue
        bar_time = df["bar_time"].iloc[i]
        if bad_hours and bar_time.hour in bad_hours:
            continue
        if use_ema_filter:
            close = df["close"].iloc[i]
            ema = df["ema_trend"].iloc[i]
            aligned = (close > ema) if d == 1 else (close < ema)
            if not aligned:
                continue
        if use_h1_filter:
            h1t = df["h1_trend"].iloc[i]
            if h1t == 0:
                continue
            if h1_mode == "aligned" and h1t != d:
                continue
            if h1_mode == "counter" and h1t != -d:
                continue
        if three_candle_pattern(df, i, d, min_gap_mult, min_fvg, require_fvg):
            c1, c2, c3 = df.iloc[i - 2], df.iloc[i - 1], df.iloc[i]
            if d == 1:
                stop = min(c1.low, c2.low, c3.low)
            else:
                stop = max(c1.high, c2.high, c3.high)
            signals.append(dict(idx=i, bar_time=bar_time, direction=d,
                                entry=c3.close, stop=stop))
    return pd.DataFrame(signals)


if __name__ == "__main__":
    df = load_m15()
    print("M15 bars:", len(df))
    sig = generate_signals(df)
    print("raw pattern occurrences:", len(sig))
    print(sig.head(20).to_string(index=False))
    sig.to_csv(r"E:\D drive\flat_trend_scalp_bot\data\pattern_signals_raw.csv", index=False)
