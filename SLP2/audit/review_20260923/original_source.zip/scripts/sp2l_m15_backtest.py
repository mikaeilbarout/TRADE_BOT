"""SP2L Advanced Bot (spike + gap + pullback) ported to M15, faithfully
matching the logic read from external_pythontrader_bot/code/SP2L/
SP2L_Advanced_Bot_Optimized.py (v5.0): 4-candle spike setup with a price
gap, a pending pullback entry (waits for low < previous low), an EMA trend
filter, and a trend-structure filter (max 1 opposite move while waiting).
SL at the pre-spike extreme. All parameters are exposed as function
arguments so scripts/sp2l_m15_optimize.py can walk-forward sweep them.
"""

import sys
import pandas as pd
import numpy as np

sys.path.insert(0, r"E:\D drive\flat_trend_scalp_bot\scripts")
from pattern_strategy import load_m15

# ---- defaults, taken directly from SP2L_Advanced_Bot_Optimized.py ----
SPIKE_CANDLE_SIZE = 1.5
PGAP_POINTS = 100
MAX_SL_DISTANCE_POINTS = 1000
TP_R = 1.0
USE_EMA_FILTER = True
EMA_PERIOD = 60
USE_TREND_FILTER = True
MAX_OPPOSITE_MOVES = 1
POINT = 0.01  # XAUUSD, 2 digits


def add_indicators(df, ema_period=EMA_PERIOD):
    df = df.copy()
    df["EMA"] = df["close"].ewm(span=ema_period, adjust=False).mean()
    return df


def detect_buy_setup(o, h, l, c, i, p_gap_price, spike_size=SPIKE_CANDLE_SIZE):
    """i = index of the 'current' (most recent) candle; -4..-1 relative to i
    map to i-3, i-2, i-1, i."""
    if i < 4:
        return False
    i4, i3, i2, i1 = i - 3, i - 2, i - 1, i
    buy0 = l[i1] < l[i2]
    buy1 = c[i2] > c[i3]
    buy2 = o[i2] > o[i3]
    buy3 = c[i3] > c[i4]
    buy4 = o[i3] > o[i4]
    buy5 = c[i2] > o[i2]
    buy6 = c[i3] > o[i3]
    buy7 = c[i4] > o[i4]
    p_gap_buy = l[i2] > h[i4] + p_gap_price
    body3 = c[i3] - o[i3]
    spike_buy = (body3 > spike_size * (c[i2] - o[i2])) & \
                (body3 > spike_size * (c[i4] - o[i4])) & \
                (body3 > spike_size * (c[i1] - o[i1]))
    return bool(buy0 & buy1 & buy2 & buy3 & buy4 & buy5 & buy6 & buy7 & p_gap_buy & spike_buy)


def detect_sell_setup(o, h, l, c, i, p_gap_price, spike_size=SPIKE_CANDLE_SIZE):
    if i < 4:
        return False
    i4, i3, i2, i1 = i - 3, i - 2, i - 1, i
    sell0 = h[i1] > h[i2]
    sell1 = c[i2] < c[i3]
    sell2 = o[i2] < o[i3]
    sell3 = c[i3] < c[i4]
    sell4 = o[i3] < o[i4]
    sell5 = c[i2] < o[i2]
    sell6 = c[i3] < o[i3]
    sell7 = c[i4] < o[i4]
    p_gap_sell = h[i2] < l[i4] - p_gap_price
    body3 = o[i3] - c[i3]
    spike_sell = (body3 > spike_size * (o[i2] - c[i2])) & \
                 (body3 > spike_size * (o[i4] - c[i4])) & \
                 (body3 > spike_size * (o[i1] - c[i1]))
    return bool(sell0 & sell1 & sell2 & sell3 & sell4 & sell5 & sell6 & sell7 & p_gap_sell & spike_sell)


def simulate(df, rr=TP_R, p_gap_price=PGAP_POINTS * POINT, max_sl_dist=MAX_SL_DISTANCE_POINTS * POINT,
             spike_size=SPIKE_CANDLE_SIZE, use_ema_filter=USE_EMA_FILTER, ema_period=EMA_PERIOD,
             use_trend_filter=USE_TREND_FILTER, max_opposite_moves=MAX_OPPOSITE_MOVES,
             max_hold_bars=500, apply_costs=True):
    """Single bar-by-bar pass matching Strategy()'s exact control flow:
    - status=True (a trade is open) blocks ALL setup/pending search, not just
      new entries -- the live bot's `if status: return` happens before the
      pending-setup block.
    - a still-unresolved pending setup does NOT lock out fresh setup
      detection on the same bar; detect_buy_setup/detect_sell_setup always
      runs and overwrites `pending` when the entry attempt didn't fire.
    """
    df = add_indicators(df, ema_period=ema_period)
    o, h, l, c = df["open"].to_numpy(), df["high"].to_numpy(), df["low"].to_numpy(), df["close"].to_numpy()
    ema = df["EMA"].to_numpy()
    bar_time = df["bar_time"].to_numpy()
    spread = df["avg_spread_price"].to_numpy() if apply_costs and "avg_spread_price" in df.columns else np.zeros(len(df))
    n = len(df)
    CONTRACT_SIZE, COMMISSION_PER_LOT = 100.0, 7.0
    commission_price_equiv = COMMISSION_PER_LOT / CONTRACT_SIZE

    trades = []
    pending = None
    open_trade = None  # dict: direction, entry, stop, target, entry_i

    for i in range(4, n):
        if open_trade is not None:
            d = open_trade["direction"]
            stop, target = open_trade["stop"], open_trade["target"]
            hit_stop = (l[i] <= stop) if d == 1 else (h[i] >= stop)
            hit_target = (h[i] >= target) if d == 1 else (l[i] <= target)
            if hit_stop or hit_target:
                exit_raw = stop if hit_stop else target
                exit_price = exit_raw - d * (spread[i] / 2)
                gross_pnl = d * (exit_price - open_trade["entry"])
                pnl = gross_pnl - (commission_price_equiv if apply_costs else 0.0)
                r_multiple = pnl / open_trade["stop_dist"]
                trades.append(dict(entry_time=open_trade["entry_time"], exit_time=pd.Timestamp(bar_time[i]),
                                   direction="long" if d == 1 else "short", pnl=pnl, r_multiple=r_multiple))
                open_trade = None
            elif i - open_trade["entry_i"] >= max_hold_bars:
                open_trade = None  # give up (should not happen at these R:R/timeframe combos)
            continue  # status=True: no setup/pending search this bar

        entered = False
        if pending is not None:
            direction = pending["direction"]
            start_pos = pending["setup_pos"]
            if direction == "BUY":
                if l[i] < l[i - 1]:
                    entry, sl = l[i], pending["sl"]
                    risk = entry - sl
                    if risk <= 0 or risk > max_sl_dist:
                        pending = None
                    else:
                        ok = True
                        if use_trend_filter:
                            opp = 0
                            for pos in range(start_pos + 1, i + 1):
                                if h[pos] > h[pos - 1]:
                                    opp = 0
                                else:
                                    opp += 1
                                    if opp > max_opposite_moves:
                                        ok = False
                                        break
                        if ok and use_ema_filter:
                            if not np.isfinite(ema[i]) or c[i] <= ema[i]:
                                ok = False
                        if ok:
                            raw_entry = entry + (spread[i] / 2)
                            stop_dist = raw_entry - sl
                            open_trade = dict(direction=1, entry=raw_entry, stop=sl,
                                              target=raw_entry + rr * stop_dist, stop_dist=stop_dist,
                                              entry_i=i, entry_time=pd.Timestamp(bar_time[i]))
                            pending = None
                            entered = True
            else:  # SELL
                if h[i] > h[i - 1]:
                    entry, sl = h[i], pending["sl"]
                    risk = sl - entry
                    if risk <= 0 or risk > max_sl_dist:
                        pending = None
                    else:
                        ok = True
                        if use_trend_filter:
                            opp = 0
                            for pos in range(start_pos + 1, i + 1):
                                if l[pos] < l[pos - 1]:
                                    opp = 0
                                else:
                                    opp += 1
                                    if opp > max_opposite_moves:
                                        ok = False
                                        break
                        if ok and use_ema_filter:
                            if not np.isfinite(ema[i]) or c[i] >= ema[i]:
                                ok = False
                        if ok:
                            raw_entry = entry - (spread[i] / 2)
                            stop_dist = sl - raw_entry
                            open_trade = dict(direction=-1, entry=raw_entry, stop=sl,
                                              target=raw_entry - rr * stop_dist, stop_dist=stop_dist,
                                              entry_i=i, entry_time=pd.Timestamp(bar_time[i]))
                            pending = None
                            entered = True

        if entered:
            continue

        if detect_buy_setup(o, h, l, c, i, p_gap_price, spike_size=spike_size):
            pending = dict(direction="BUY", setup_pos=i, sl=l[i - 3])
        elif detect_sell_setup(o, h, l, c, i, p_gap_price, spike_size=spike_size):
            pending = dict(direction="SELL", setup_pos=i, sl=h[i - 3])

    return pd.DataFrame(trades)


def summarize(trades):
    if len(trades) == 0:
        return dict(n_trades=0)
    wins = trades[trades["pnl"] > 0]
    win_rate = len(wins) / len(trades)
    r = trades["r_multiple"]
    cum_r = r.cumsum()
    max_dd_r = (cum_r.cummax().clip(lower=0) - cum_r).max()
    total_r = r.sum()
    recovery = total_r / max_dd_r if max_dd_r and max_dd_r > 0 else np.nan
    gain = r.clip(lower=0).sum()
    loss = -r.clip(upper=0).sum()
    pf = gain / loss if loss > 0 else np.inf
    return dict(n_trades=len(trades), win_rate=round(win_rate, 3), avg_r=round(r.mean(), 3),
               profit_factor=round(pf, 3) if np.isfinite(pf) else pf, total_r=round(total_r, 2),
               max_dd_r=round(max_dd_r, 2), recovery_factor=round(recovery, 3) if pd.notna(recovery) else np.nan)


if __name__ == "__main__":
    df = load_m15()
    n = len(df)
    split_i = int(n * 0.70)
    train = df.iloc[:split_i].reset_index(drop=True)
    test = df.iloc[split_i:].reset_index(drop=True)
    print(f"train: {train.bar_time.iloc[0]} -> {train.bar_time.iloc[-1]} ({len(train)} bars)")
    print(f"test : {test.bar_time.iloc[0]} -> {test.bar_time.iloc[-1]} ({len(test)} bars)")
    print()

    print("=== default config (TP_R=1.0, exact port of live bot settings) ===")
    trades_tr = simulate(train, rr=TP_R)
    trades_te = simulate(test, rr=TP_R)
    print("TRAIN:", summarize(trades_tr))
    print("TEST :", summarize(trades_te))
