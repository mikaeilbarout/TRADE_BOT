"""Validated UTC snapshots. API errors never mean an empty account."""
import math
import time
import MetaTrader5 as mt5
import pandas as pd
from bot import config

TIMEFRAMES = {"M5": mt5.TIMEFRAME_M5, "M15": mt5.TIMEFRAME_M15, "H1": mt5.TIMEFRAME_H1}
MINUTES = {"M5": 5, "M15": 15, "H1": 60}


def utc_now():
    return pd.Timestamp.now(tz="UTC").tz_localize(None)


def account():
    value = mt5.account_info()
    if value is None:
        raise RuntimeError(f"account_info: {mt5.last_error()}")
    return value


def identity():
    acc = account()
    return f"{acc.server}:{acc.login}:{acc.currency}"


def get_symbol_info(symbol):
    value = mt5.symbol_info(symbol)
    if value is None:
        raise RuntimeError(f"symbol_info {symbol}: {mt5.last_error()}")
    return value


def get_tick(symbol, now=None):
    tick = mt5.symbol_info_tick(symbol)
    if tick is None:
        raise RuntimeError(f"No tick for {symbol}")
    age = (time.time() if now is None else now) - tick.time_msc / 1000
    if not (-2 <= age <= config.MAX_TICK_AGE_SECONDS):
        raise RuntimeError(f"Stale/future tick for {symbol}: age={age:.1f}s")
    if not all(math.isfinite(x) and x > 0 for x in (tick.bid, tick.ask)) or tick.ask < tick.bid:
        raise RuntimeError(f"Invalid quote for {symbol}")
    return tick


def positions(symbol=None):
    result = mt5.positions_get(**({"symbol": symbol} if symbol else {}))
    if result is None:
        raise RuntimeError(f"positions_get: {mt5.last_error()}")
    return result


def rates_frame(rates, timeframe, asof):
    if rates is None or len(rates) == 0:
        raise RuntimeError(f"No {timeframe} bars")
    frame = pd.DataFrame(rates).rename(columns={"time": "bar_time"})
    frame["bar_time"] = pd.to_datetime(frame["bar_time"], unit="s").astype("datetime64[ns]")
    frame = frame.sort_values("bar_time").drop_duplicates("bar_time")
    frame = frame[frame.bar_time + pd.Timedelta(minutes=MINUTES[timeframe]) <= asof]
    return frame.reset_index(drop=True)


def get_bars(symbol, timeframe, count, asof=None):
    asof = utc_now() if asof is None else pd.Timestamp(asof)
    rates = mt5.copy_rates_from_pos(symbol, TIMEFRAMES[timeframe], 0, count + 2)
    frame = rates_frame(rates, timeframe, asof).tail(count).reset_index(drop=True)
    if len(frame) < count:
        raise RuntimeError(f"Insufficient history {symbol}/{timeframe}: {len(frame)}/{count}")
    return frame


def get_history(symbol, timeframe, start, end):
    rates = mt5.copy_rates_range(symbol, TIMEFRAMES[timeframe],
        pd.Timestamp(start).tz_localize("UTC").to_pydatetime(),
        pd.Timestamp(end).tz_localize("UTC").to_pydatetime())
    return rates_frame(rates, timeframe, pd.Timestamp(end))


def get_account_balance():
    return account().balance
